"""
This module has the register function for registering the
user in the file. To make it accessable for server to
check the credentials for appropiate the login.
"""
async def registration(reader, writer):
    """
    This function is used to register the user
    credentials to the file. And also check if the same user is
    registered or not. If registered application halts by
    showing the message.
    """
    message = "/\/\/\/\Registration Form/\/\/\/\ \nEnter your name :"
    writer.write(message.encode())
    print("Waiting for name")
    res = await reader.read(100)
    # getting name
    user = res.decode().strip()
    message = "Create a User Name : "
    writer.write(message.encode())
    print("Waiting for User Name")
    # getting User Name
    res = await reader.read(100)
    userid = res.decode().strip()
    message = "Enter your Password :"
    writer.write(message.encode())
    print("Waiting for Password")
    # getting password
    res = await reader.read(100)
    password = res.decode().strip()
    confirm = False
    location = "C:\\Users\\nikhil\\Assignment3\\root\\admin\\Registration.txt"
    # checking the user registered before or not
    with open(location, 'r') as fread:
        for line in fread:
            if userid and password in line:
                confirm = True
                break
    # if not registered make user register
    if not confirm:
        with open(location, 'a') as file:
            file.write(userid + ':')
            file.write(password + ', \n')
        message = f"{user} is Registered Succcessfully."
        writer.write(message.encode())
        print("Registration Done")
    else:
        message = "Request Denied\nYou are already Registered"
        writer.write(message.encode())
        print("Denied\n User already Registered")