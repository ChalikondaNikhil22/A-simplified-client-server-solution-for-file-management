"""
This module is of testing the operations in the server
module and the test is done with the unittest module.
"""
import unittest
import operations

class TestOperations(unittest.TestCase):
    """
    In this class the testcase was taken to test the server code
    (operations) commands, which gives from server to client.
    There are four functions in the sense of four different testcases
    Ofcourse the methods was passed the test without any fail.
    """
    def test1_all_functions(self):
       
        op = operations.Operations("nikhil123")

        cref = op.create_folder("bat")
        self.assertEqual(cref, True)

        wfill = op.write_file("bat", "snoopy", "Snoopy is good bat")
        self.assertEqual(wfill, True)

        rfill = op.read_file("bat", "snoopy")
        self.assertEqual(rfill, "Snoopy is good bat")

        c = op.change_folname("bats")
        self.assertEqual(c, True)

    def test2_all_functions(self):
        
        op = operations.Operations("vam123")

        cref = op.create_folder("lions")
        self.assertEqual(cref, True)

        wfill = op.write_file("lions", "tommy", "tommy is good lion")
        self.assertEqual(wfill, True)

        rfill = op.read_file("lions", "tommy")
        self.assertEqual(rfill, "tommy is good lion")

        c = op.change_folname("lions")
        self.assertEqual(c, True)

    def test3_all_functions(self):
        
        op = operations.Operations("ram123")

        cref = op.create_folder("monkey")
        self.assertEqual(cref, True)

        wfill = op.write_file("monkey", "cuty", "cuty is good monkey")
        self.assertEqual(wfill, True)

        rfill = op.read_file("monkey", "cuty")
        self.assertEqual(rfill, "cuty is good monkey")

        c = op.change_folname("monkey")
        self.assertEqual(c, True)

    def test4_all_functions(self):
       
        op = operations.Operations("prud123")

        cref = op.create_folder("name")
        self.assertEqual(cref, True)

        wfill = op.write_file("name", "boy", "my name is good boy")
        self.assertEqual(wfill, True)

        rfill = op.read_file("name", "boy")
        self.assertEqual(rfill, "my name is good boy")

        c = op.change_folname("name")
        self.assertEqual(c, True)

if __name__ == "__main__":
    unittest.main()
