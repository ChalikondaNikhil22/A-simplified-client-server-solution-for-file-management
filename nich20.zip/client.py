"""
This module shall create a connection between client and server to connect 
by using IPAdress and port number. And asks user to have
registration and login.
"""
import asyncio
import cregister
import clogin

async def client():
    """
    This async function is implemented to connect the client
    to server and send and receive data
    from server and show the client.
    """
    reader, writer = await asyncio.open_connection('127.0.0.1', 8088)
    res = await reader.read(150)
    message = res.decode().strip()
    aurgment = input(message)
    writer.write(aurgment.encode())
    if aurgment == '1':
        await cregister.registration(reader, writer)

    if aurgment != '1':
        await clogin.login(reader, writer)

asyncio.run(client())