"""
This is the SERVER program with asyncio.
---------------------------------------
This program is a sort of heart to the application. Server code is designed
to run continuously until we command it to stop with CTRL+C.
This pragram, helps initiate the application.
Here the function is responsible for choosing the login and register option.
After setting the options, user has the oppurtinity to acess his/her directories.
"""
import asyncio
import signal
import sregister
import slogin

# signal to stop server when clicked CTRL+C
signal.signal(signal.SIGINT, signal.SIG_DFL)

# async function of server code to choose the option Registration or Login
async def choose_option(reader, writer):
    """
    This function provides user with an opportunity to choose the
    Registration or Login function, where the code is divided in few modules.
    Based on the command given by the user the program shall call the function
    and run the function.
    >>> option = 1
    """
    startingMessage = """Welcome User you have two option\nChoose Register or Login
    1. Register
    2. Login (If you have already Registered)
    Please enter your option :"""
    writer.write(startingMessage.encode())
    res = await reader.read(150)
    option = res.decode().strip()
    print(f"User chose to {option}")
    if option == '1':
        # calling the registration function
        await sregister.registration(reader, writer)
    else:
        # calling the login function
        await slogin.login(reader, writer)

async def main():
    """
    This is used to initiate the server and make the server
    run continuously until press CTRL+C.
    The client with the same ipadress and port number will
    have access to connect with the server.
    """
    serv = await asyncio.start_server(
        choose_option, '127.0.0.1', 8088)

    # showing address
    addr = serv.sockets[0].getsockname()
    print(f'The SERVER is initialised and serving on {addr}')
    print("Waiting for the Clients....:-)")

    # makes server to run forever
    async with serv:
        await serv.serve_forever()

asyncio.run(main())