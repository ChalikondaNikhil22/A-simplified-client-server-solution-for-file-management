"""
This module includes the client registration function, which
is implemented with asyncio.
"""

async def registration(reader, writer):
    """
    This function helps the user to register for the
    application.
    The parameters included are:
    name - name of user
    User id - Username of user
    Password - Password of user
    """
    for _ in range(3):
        res = await reader.read(100)
        message = res.decode().strip()
        s = input(message)
        writer.write(s.encode())
    res = await reader.read(100)
    finalMessage = res.decode().strip()
    print(finalMessage)
    print("----Please Login now by clicking login after running client----")