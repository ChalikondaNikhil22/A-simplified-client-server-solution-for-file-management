"""
This module includes the functionality that requests the commands
from the client to the server along with the requested commands 
and also stores the commands of the client given to display.
"""
import sys

async def login(reader, writer):
    """
    This function is client login function, used for login
    purposes making the client interface intractive
    and also provides many facilites to the user to
    intract with his own storage and grants access to edit i.e create
    , read, write file in the user storage.
    """
    lis = [
        "", "createfolder", "writefile", "readfile", "list", "changepath", "comds"
        ]
    comm = []
    res = await reader.read(100)
    message = res.decode().strip()
    userId = input(message)
    writer.write(userId.encode())
    res = await reader.read(100)
    message = res.decode().strip()
    passw = input(message)
    writer.write(passw.encode())
    res = await reader.read(10000)
    message = res.decode().strip()
    print(message)
    while True:
        res = await reader.read(10000)
        message = res.decode().strip()
        print(message)
        if message in ["You have logged in already\nAccess Denied","Invalid Username or Password"]:
            sys.exit()
        ch = input("Enter your choice : ")
        comm.append(int(ch))
        writer.write(ch.encode())
        if ch == '1':
            info = await reader.read(100)
            message = info.decode().strip()
            functionName = input(message)
            writer.write(functionName.encode())
            info = await reader.read(100)
            message = info.decode().strip()
            print(message)
        elif ch == "2":
            info = await reader.read(100)
            message = info.decode().strip()
            folname = input(message)
            writer.write(folname.encode())
            info = await reader.read(100)
            message = info.decode().strip()
            filename = input(message)
            writer.write(filename.encode())
            info = await reader.read(100)
            message = info.decode().strip()
            iinfo = input(message)
            writer.write(iinfo.encode())
            info = await reader.read(100)
            message = info.decode().strip()
            print(message)
        elif ch == "3":
            info = await reader.read(100)
            message = info.decode().strip()
            folname = input(message)
            writer.write(folname.encode())
            info = await reader.read(100)
            message = info.decode().strip()
            filename = input(message)
            writer.write(filename.encode())
            info = await reader.read(100)
            message = info.decode().strip()
            print(message)
        elif ch == "4":
            info = await reader.read(100)
            message = info.decode().strip()
            print(message)
            writer.write("heading".encode())
            info = await reader.read(100)
            sname = info.decode().strip()
            name = list(sname.split(" "))
            writer.write("file names".encode())
            info = await reader.read(100)
            ssize = info.decode().strip()
            size = list(ssize.split(" "))
            writer.write("file sizes".encode())
            info = await reader.read(400)
            stripData = info.decode().strip()
            cr = list(stripData.split("  "))
            writer.write("created".encode())
            info = await reader.read(400)
            smod = info.decode().strip()
            mod = list(smod.split("  "))
            writer.write("modified".encode())
            for fol in range(len(name)):
                print(f"{name[fol]}  {size[fol]}   {cr[fol]}  {mod[fol]}")
        elif ch == '5':
            info = await reader.read(100)
            message = info.decode().strip()
            on = input(message)
            writer.write(on.encode())
            info = await reader.read(100)
            message = info.decode().strip()
            print(message)
        elif ch == "0":
            break
        elif ch == "6":
            print("The list of comm are:")
            for com in range(len(comm)):
                print(lis[comm[com]], end="||")
            print()
        else:
            print("Wrong Command")
    res = await reader.read(100)
    message = res.decode().strip()
    print(message)